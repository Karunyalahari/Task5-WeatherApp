# Weather App
A simple Android app to fetch current weather using OpenWeatherMap API.

## Features
- Enter city name and fetch weather
- Displays temperature and condition
- Built with Kotlin and Jetpack Compose

## Setup
1. Clone the repo
2. Replace `YOUR_API_KEY` with your OpenWeatherMap key
3. Build and run in Android Studio

## Deployment
- Release APK can be generated via `Build > Generate Signed Bundle`
- Ready for Play Store submission

## Author
ApexPlanet Internship - Final Task 5 Submission
