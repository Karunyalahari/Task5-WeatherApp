package com.example.weatherapp

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.weatherapp.ui.theme.WeatherAppTheme
import kotlinx.coroutines.launch
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            WeatherAppTheme {
                Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    WeatherScreen()
                }
            }
        }
    }
}

@Composable
fun WeatherScreen() {
    val scope = rememberCoroutineScope()
    var city by remember { mutableStateOf("") }
    var weather by remember { mutableStateOf<WeatherResponse?>(null) }

    val api = Retrofit.Builder()
        .baseUrl("https://api.openweathermap.org/data/2.5/")
        .addConverterFactory(GsonConverterFactory.create())
        .build()
        .create(WeatherApi::class.java)

    Column(modifier = Modifier.padding(16.dp)) {
        OutlinedTextField(value = city, onValueChange = { city = it }, label = { Text("Enter city") })
        Spacer(modifier = Modifier.height(8.dp))
        Button(onClick = {
            scope.launch {
                weather = try {
                    api.getWeather(city, "metric", "YOUR_API_KEY")
                } catch (e: Exception) {
                    null
                }
            }
        }) {
            Text("Get Weather")
        }
        Spacer(modifier = Modifier.height(16.dp))
        weather?.let {
            Text("Temperature: ${it.main.temp} °C")
            Text("Condition: ${it.weather[0].description}")
        }
    }
}
